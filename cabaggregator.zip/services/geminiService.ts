import { GoogleGenAI, Type, Schema } from "@google/genai";
import { SearchResult } from '../types';

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const rideSchema: Schema = {
  type: Type.OBJECT,
  properties: {
    distance: { type: Type.STRING, description: "Total distance e.g. 5.2 km" },
    duration: { type: Type.STRING, description: "Total trip time e.g. 25 mins" },
    options: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          provider: { type: Type.STRING, description: "Uber, Rapido, or Namma Yatri" },
          type: { type: Type.STRING, description: "Bike, Auto, Mini, Sedan, SUV" },
          price: { type: Type.INTEGER, description: "Price in local currency" },
          eta: { type: Type.STRING, description: "Time away in mins, e.g. 3 mins" },
          rating: { type: Type.NUMBER, description: "Driver rating 4.0-5.0" },
          surge: { type: Type.BOOLEAN, description: "Is surge pricing active?" }
        }
      }
    }
  }
};

export const getFareEstimates = async (origin: string, destination: string): Promise<SearchResult> => {
  const prompt = `
    Generate a realistic cab fare comparison for a trip from "${origin}" to "${destination}".
    Assume the location is in a busy Indian city like Bangalore.
    
    Provide a diverse set of options (at least 8-10 total) across these providers: Uber, Rapido, Namma Yatri.
    Include vehicle types like Bike, Auto, Mini, Sedan, SUV where appropriate for the provider.
    
    - Rapido: Bike, Auto
    - Namma Yatri: Auto, Cab
    - Uber: Moto, Auto, Go, Premier, XL
    
    Vary the prices slightly to make it realistic. Namma Yatri usually has lower platform fees but direct driver payment. Rapido is cheap for bikes. Uber varies.
    Simulate some surge pricing if it sounds like a peak route or high traffic area.
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
        responseSchema: rideSchema
      }
    });

    const text = response.text;
    if (!text) throw new Error("No response from AI");

    const data = JSON.parse(text);
    
    // Post-process to ensure IDs and valid enums if needed, though simpler to map directly
    const options = data.options.map((opt: any, index: number) => ({
      id: `ride-${index}`,
      provider: opt.provider,
      type: opt.type,
      price: opt.price,
      eta: opt.eta,
      tripDuration: data.duration,
      rating: opt.rating,
      surge: opt.surge
    }));

    return {
      details: {
        distance: data.distance,
        duration: data.duration,
        origin,
        destination
      },
      options
    };

  } catch (error) {
    console.error("Error fetching fare estimates:", error);
    // Fallback mock data in case of API failure to keep the app interactive
    return {
      details: { distance: "0 km", duration: "0 mins", origin, destination },
      options: []
    };
  }
};
