import React, { useState, useMemo } from 'react';
import { RideOption } from '../types';
import RideCard from './RideCard';
import { SlidersHorizontal, ArrowUpDown } from 'lucide-react';

interface RideListProps {
  options: RideOption[];
  distance: string;
  duration: string;
  onSelectRide: (ride: RideOption) => void;
}

type SortMode = 'price' | 'eta';

const RideList: React.FC<RideListProps> = ({ options, distance, duration, onSelectRide }) => {
  const [sortMode, setSortMode] = useState<SortMode>('price');
  const [activeProvider, setActiveProvider] = useState<string | 'ALL'>('ALL');

  const filteredOptions = useMemo(() => {
    let filtered = options;
    if (activeProvider !== 'ALL') {
      filtered = filtered.filter(opt => opt.provider === activeProvider);
    }
    
    return filtered.sort((a, b) => {
      if (sortMode === 'price') return a.price - b.price;
      // naive eta sort assuming format "X mins"
      const etaA = parseInt(a.eta) || 0;
      const etaB = parseInt(b.eta) || 0;
      return etaA - etaB;
    });
  }, [options, activeProvider, sortMode]);

  const providers = Array.from(new Set(options.map(o => o.provider)));

  return (
    <div className="flex-1 bg-gray-50 rounded-t-3xl pt-6 px-4 pb-20 relative z-0 animate-in fade-in duration-500 slide-in-from-bottom-4">
      {/* Trip Summary Pill */}
      <div className="flex justify-center mb-6">
        <div className="bg-white border border-gray-200 shadow-sm text-gray-600 text-xs font-semibold px-4 py-1.5 rounded-full flex gap-3">
            <span>{distance}</span>
            <span className="text-gray-300">|</span>
            <span>~{duration}</span>
        </div>
      </div>

      {/* Controls */}
      <div className="flex items-center justify-between mb-4">
        <div className="flex gap-2 overflow-x-auto scrollbar-hide pb-2">
          <button
             onClick={() => setActiveProvider('ALL')}
             className={`px-4 py-1.5 rounded-full text-sm font-medium whitespace-nowrap transition ${activeProvider === 'ALL' ? 'bg-gray-900 text-white shadow-md' : 'bg-white text-gray-600 border border-gray-200'}`}
          >
            All
          </button>
          {providers.map(p => (
             <button
                key={p}
                onClick={() => setActiveProvider(p)}
                className={`px-4 py-1.5 rounded-full text-sm font-medium whitespace-nowrap transition ${activeProvider === p ? 'bg-gray-900 text-white shadow-md' : 'bg-white text-gray-600 border border-gray-200'}`}
             >
               {p}
             </button>
          ))}
        </div>
        
        <button 
            onClick={() => setSortMode(prev => prev === 'price' ? 'eta' : 'price')}
            className="p-2 bg-white border border-gray-200 rounded-full text-gray-600 hover:bg-gray-50 shadow-sm"
        >
            {sortMode === 'price' ? <ArrowUpDown size={18} /> : <SlidersHorizontal size={18} />}
        </button>
      </div>

      <div className="flex justify-between items-center text-xs text-gray-500 mb-3 px-1">
        <span>{filteredOptions.length} rides available</span>
        <span>Sorted by {sortMode === 'price' ? 'Price' : 'Pickup Time'}</span>
      </div>

      {/* List */}
      <div className="space-y-3">
        {filteredOptions.map(option => (
          <RideCard 
            key={option.id} 
            option={option} 
            onSelect={onSelectRide}
          />
        ))}
      </div>
      
      {filteredOptions.length === 0 && (
          <div className="text-center py-12 text-gray-400">
              <p>No rides found for this filter.</p>
          </div>
      )}
    </div>
  );
};

export default RideList;