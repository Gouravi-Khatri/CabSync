import React from 'react';
import { RideOption, Provider } from '../types';
import { Car, Bike, Zap, Star, Clock, ChevronRight } from 'lucide-react';

interface RideCardProps {
  option: RideOption;
  onSelect: (option: RideOption) => void;
}

const getProviderColor = (provider: string) => {
  switch (provider) {
    case Provider.UBER: return 'bg-black text-white';
    case Provider.RAPIDO: return 'bg-yellow-400 text-black';
    case Provider.NAMMA_YATRI: return 'bg-orange-500 text-white';
    default: return 'bg-gray-500 text-white';
  }
};

const getProviderLogoText = (provider: string) => {
    switch(provider) {
        case 'Uber': return 'Uber';
        case 'Rapido': return 'Rapido';
        case 'Namma Yatri': return 'NY';
        default: return provider[0];
    }
}

const RideCard: React.FC<RideCardProps> = ({ option, onSelect }) => {
  return (
    <div 
        onClick={() => onSelect(option)}
        className="bg-white p-4 rounded-2xl shadow-sm border border-gray-100 hover:border-blue-400 hover:shadow-md active:scale-[0.99] transition-all cursor-pointer group relative overflow-hidden"
    >
      {/* Selection Indicator on Hover */}
      <div className="absolute inset-y-0 left-0 w-1 bg-blue-500 transform -translate-x-full group-hover:translate-x-0 transition-transform duration-200"></div>

      <div className="flex justify-between items-center mb-2">
        <div className="flex items-center gap-3">
          <div className={`w-12 h-12 rounded-xl flex items-center justify-center font-bold shadow-sm text-xs ${getProviderColor(option.provider)}`}>
            {getProviderLogoText(option.provider)}
          </div>
          <div>
            <h3 className="font-bold text-gray-900 flex items-center gap-2">
              {option.type}
              {option.surge && <Zap size={14} className="text-yellow-500 fill-current animate-pulse" />}
            </h3>
            <div className="text-xs text-gray-500 flex items-center gap-1">
              <Clock size={12} />
              <span>{option.eta} away</span>
            </div>
          </div>
        </div>
        <div className="text-right">
          <div className="text-xl font-bold text-gray-900">₹{option.price}</div>
           {option.rating && (
            <div className="flex items-center justify-end gap-1 text-xs text-gray-400">
                <span>{option.rating}</span>
                <Star size={10} fill="currentColor" className="text-yellow-400" />
            </div>
           )}
        </div>
      </div>
      
      <div className="flex justify-between items-center mt-2">
          {option.surge ? (
            <div className="text-xs text-yellow-700 bg-yellow-50 px-2 py-1 rounded flex items-center gap-1">
                <Zap size={12} /> Surge pricing active
            </div>
          ) : (
             <div className="text-xs text-green-600 bg-green-50 px-2 py-1 rounded flex items-center gap-1">
                Best Price
             </div>
          )}
          
          <div className="flex items-center text-blue-600 text-sm font-medium opacity-0 group-hover:opacity-100 transition-opacity -translate-x-2 group-hover:translate-x-0">
             Book <ChevronRight size={16} />
          </div>
      </div>
    </div>
  );
};

export default RideCard;