import React, { useState, useEffect } from 'react';
import { RideOption } from '../types';
import { CheckCircle, Phone, MessageSquare, User, MapPin } from 'lucide-react';

interface BookingScreenProps {
  ride: RideOption;
  onClose: () => void;
}

const BookingScreen: React.FC<BookingScreenProps> = ({ ride, onClose }) => {
  const [status, setStatus] = useState<'searching' | 'confirmed'>('searching');

  useEffect(() => {
    // Simulate finding a driver
    const timer = setTimeout(() => {
      setStatus('confirmed');
    }, 3000);
    return () => clearTimeout(timer);
  }, []);

  if (status === 'searching') {
    return (
      <div className="flex flex-col items-center justify-center h-full py-12">
         <div className="relative w-24 h-24 mb-8">
            <div className="absolute inset-0 border-4 border-gray-100 rounded-full"></div>
            <div className="absolute inset-0 border-4 border-blue-600 rounded-full border-t-transparent animate-spin"></div>
            <div className="absolute inset-0 flex items-center justify-center">
                <span className="text-3xl">🚕</span>
            </div>
         </div>
         <h3 className="text-xl font-bold text-gray-900 mb-2 animate-pulse">Contacting {ride.provider}...</h3>
         <p className="text-gray-500 text-center max-w-xs">
            We are looking for a {ride.type} driver nearby. Please wait a moment.
         </p>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full pt-2 animate-in fade-in slide-in-from-bottom-8 duration-500">
        <div className="text-center mb-6">
            <div className="inline-flex items-center justify-center w-16 h-16 bg-green-100 text-green-600 rounded-full mb-4 ring-4 ring-green-50">
                <CheckCircle size={32} />
            </div>
            <h2 className="text-2xl font-bold text-gray-900">Booking Confirmed!</h2>
            <p className="text-gray-500">Your ride is arriving in {ride.eta}.</p>
        </div>

        {/* Driver Card */}
        <div className="bg-white border border-gray-200 rounded-2xl p-5 shadow-sm mb-6">
            <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-3">
                    <div className="w-14 h-14 bg-gradient-to-br from-gray-100 to-gray-200 rounded-full flex items-center justify-center text-gray-500 border border-gray-300">
                        <User size={28} />
                    </div>
                    <div>
                        <h3 className="font-bold text-gray-900 text-lg">Rajesh Kumar</h3>
                        <div className="flex items-center gap-2 text-sm text-gray-500">
                            <span className="bg-yellow-100 text-yellow-700 px-1.5 py-0.5 rounded text-xs font-bold">4.8 ★</span>
                            <span>• KA 05 MJ 1029</span>
                        </div>
                    </div>
                </div>
                <div className="text-right bg-blue-50 px-3 py-2 rounded-lg">
                    <div className="font-bold text-lg text-blue-700">{ride.eta}</div>
                    <div className="text-xs text-blue-500 font-medium">min away</div>
                </div>
            </div>

            <div className="flex gap-3">
                 <button className="flex-1 flex items-center justify-center gap-2 bg-gray-50 hover:bg-gray-100 text-gray-800 py-3 rounded-xl font-semibold transition border border-gray-200">
                    <MessageSquare size={18} />
                    Message
                 </button>
                 <button className="flex-1 flex items-center justify-center gap-2 bg-black hover:bg-gray-800 text-white py-3 rounded-xl font-semibold transition shadow-lg shadow-gray-200">
                    <Phone size={18} />
                    Call Driver
                 </button>
            </div>
        </div>
        
        {/* Trip Details */}
        <div className="bg-gray-50 rounded-xl p-5 mb-auto border border-gray-100">
             <div className="flex justify-between items-center mb-3 pb-3 border-b border-gray-200">
                <div className="flex items-center gap-2 text-gray-600">
                    <MapPin size={16} />
                    <span className="text-sm font-medium">Destination</span>
                </div>
                <span className="text-xs bg-gray-200 px-2 py-1 rounded text-gray-600">Drop off</span>
             </div>
             
             <div className="flex justify-between items-center mb-2">
                <span className="text-gray-500 text-sm">Estimated Cost</span>
                <span className="font-bold text-gray-900 text-lg">₹{ride.price}</span>
             </div>
             <div className="flex justify-between items-center">
                <span className="text-gray-500 text-sm">Payment Method</span>
                <span className="text-gray-900 text-sm font-medium flex items-center gap-2">
                    <div className="w-2 h-2 bg-green-500 rounded-full"></div> Cash
                </span>
             </div>
        </div>

        <button 
            onClick={onClose}
            className="w-full bg-gray-900 text-white font-bold py-4 rounded-xl hover:bg-gray-800 transition mt-6 shadow-xl"
        >
            Return to Home
        </button>
    </div>
  );
}

export default BookingScreen;