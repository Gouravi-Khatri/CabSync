import React from 'react';
import { MapPin } from 'lucide-react';

const MapVisualizer: React.FC = () => {
  return (
    <div className="w-full h-48 bg-blue-50 relative overflow-hidden rounded-b-3xl border-b border-gray-200">
        {/* Decorative abstract map elements */}
        <div className="absolute top-0 left-0 w-full h-full opacity-30">
            <div className="absolute top-4 left-[-10%] w-[120%] h-2 bg-white rotate-12"></div>
            <div className="absolute top-12 left-[-10%] w-[120%] h-4 bg-white -rotate-3"></div>
            <div className="absolute top-24 left-[-10%] w-[120%] h-3 bg-white rotate-6"></div>
            <div className="absolute bottom-8 left-[-10%] w-[120%] h-5 bg-white -rotate-12"></div>
            
            <div className="absolute top-0 right-12 w-2 h-full bg-white rotate-12"></div>
            <div className="absolute top-0 left-24 w-3 h-full bg-white -rotate-6"></div>
        </div>

        {/* Mock Route */}
        <div className="absolute inset-0 flex items-center justify-center">
            <div className="relative w-3/4 h-1/2">
                {/* Line */}
                <svg className="w-full h-full overflow-visible">
                    <path 
                        d="M10,40 C 80,10 200,80 280,20" 
                        fill="none" 
                        stroke="#3B82F6" 
                        strokeWidth="4" 
                        strokeDasharray="8 4"
                        className="drop-shadow-sm"
                    />
                </svg>
                
                {/* Points */}
                <div className="absolute top-[32px] left-[2px] w-4 h-4 bg-green-500 rounded-full border-2 border-white shadow-md z-10"></div>
                <div className="absolute top-[14px] right-[5px] text-red-500 drop-shadow-md z-10">
                    <MapPin size={24} fill="currentColor" className="text-red-500" />
                </div>
            </div>
        </div>
    </div>
  );
};

export default MapVisualizer;
