import React, { useState } from 'react';
import { MapPin, Navigation, Search, RotateCw } from 'lucide-react';

interface SearchFormProps {
  onSearch: (origin: string, destination: string) => void;
  isLoading: boolean;
}

const SearchForm: React.FC<SearchFormProps> = ({ onSearch, isLoading }) => {
  const [origin, setOrigin] = useState('');
  const [destination, setDestination] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (origin && destination) {
      onSearch(origin, destination);
    }
  };

  return (
    <div className="bg-white rounded-b-3xl shadow-xl p-6 border-t border-gray-100 relative z-20">
      <form onSubmit={handleSubmit} className="flex flex-col gap-4">
        <div className="relative">
          <div className="absolute left-3 top-3.5 text-green-500 z-10">
            <div className="w-3 h-3 bg-green-500 rounded-full ring-4 ring-green-100"></div>
          </div>
          <input
            type="text"
            placeholder="Pickup location (e.g., Koramangala)"
            value={origin}
            onChange={(e) => setOrigin(e.target.value)}
            className="w-full pl-10 pr-4 py-3 bg-gray-50 rounded-xl border border-gray-200 focus:border-blue-500 focus:ring-2 focus:ring-blue-100 outline-none transition text-gray-900 placeholder-gray-500 font-medium"
            required
          />
        </div>

        <div className="relative">
          <div className="absolute left-8 top-[-18px] h-8 w-0.5 border-l-2 border-dashed border-gray-300 -z-10"></div>
          <div className="absolute left-3 top-3.5 text-red-500 z-10">
            <MapPin size={16} fill="currentColor" />
          </div>
          <input
            type="text"
            placeholder="Where to? (e.g., Indiranagar)"
            value={destination}
            onChange={(e) => setDestination(e.target.value)}
            className="w-full pl-10 pr-4 py-3 bg-gray-50 rounded-xl border border-gray-200 focus:border-blue-500 focus:ring-2 focus:ring-blue-100 outline-none transition text-gray-900 placeholder-gray-500 font-medium"
            required
          />
        </div>

        <button
          type="submit"
          disabled={isLoading || !origin || !destination}
          className="mt-2 w-full bg-black text-white font-bold py-4 rounded-xl hover:bg-gray-800 active:scale-[0.98] transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2 shadow-lg shadow-gray-200"
        >
          {isLoading ? (
            <>
              <RotateCw className="animate-spin" size={20} />
              <span>Finding best fares...</span>
            </>
          ) : (
            <>
              <Search size={20} />
              <span>Find Rides</span>
            </>
          )}
        </button>
      </form>
    </div>
  );
};

export default SearchForm;